<?php
/*
 * Configuration Database
 */
return array(
    'host' => "localhost",
    'username' => "root",
    'password' => "",
    'dbname' => "bukri2",
    // 'port' => "", // sementara menggunakan port bawaan
);

?>
